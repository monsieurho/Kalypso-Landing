
chrome.runtime.onMessage.addListener(function(request, sender, callback) {
  messageCenter(request, sender, callback)
  return true
})

function messageCenter(request, sender, callback) {
  console.log('popup onMessage: ' + JSON.stringify(request))
  switch (request.action) {
    case "status":
      reloadButtonStatus(request.status)
      reloadProcessingJob(request.processingJob)
      break
    case "processing":
      reloadProcessingJob(request.processingJob)
      break
    case "usage-result":
      reloadUsageResult(request.total_usage)
  }
  callback()
}

function reloadUsageResult(total_usage) {
  document.getElementById('usage_result').innerHTML = `${(total_usage / 1024).toFixed(0)} kb`
}

function reloadProcessingJob(job) {
  document.getElementById('processing').innerHTML = job
}

function e(data, callback) {
  chrome.runtime.sendMessage(data, callback)
}

var disbaleInterval = null
function toggle() {
  on_off_button.disabled = true

  clearInterval(disbaleInterval)
  disbaleInterval = setInterval(()=>{on_off_button.disabled = false}, 1000)

  if (on_off_button.innerText === 'Start') {
    e({ action: 'connect', id: userId })
    document.getElementById("myCheck").checked = true;
    start()


  } else {
    e({ action: 'disconnect' })
    document.getElementById("myCheck").checked = false;
pause()

  }
}



chrome.storage.local.get(['key'], function(result) {
  console.log('Wallet address currently is ' + result.key);

 userId = result.key;
  console.log('test: ' + userId)

});

setTimeout(function(){
  console.log('test2: ' + userId);
  document.getElementById('walletinput').setAttribute('value', userId);
}, 1000);

var on_off_button = null
document.addEventListener('DOMContentLoaded', () => {
  on_off_button = document.getElementById('on_off_button')
  on_off_button.addEventListener('click', toggle)
  var checkbox = document.getElementById("myCheck");
  checkbox.addEventListener('change', toggle)



  document.getElementById('usage_button').addEventListener('click', ()=>{
    e({ action: 'get-usage' })
  })
  
})

function reloadButtonStatus(status) {
  if (status === 'connected') {
    on_off_button.innerText = 'Stop'
    on_off_button.style.backgroundColor = 'green'
    document.getElementById("myCheck").checked = true;


  } else {
    on_off_button.innerText = 'Start'
    on_off_button.style.backgroundColor = ''
    document.getElementById("myCheck").checked = false;


  }
}
window.onload = () => {
  e({ action: 'get-status' })
}


// added by Greg ----------------
// Menu toggle

document.getElementById("menu").onclick = function() {menuFunction()};

    var menu = document.querySelector('.menu') // Using a class instead, see note below.
    var menuOverlay = document.querySelector('.menu-overlay') // Using a class instead, see note below.


    function menuFunction()
    {
        menu.classList.toggle('open');
        menuOverlay.classList.toggle('open');
        console.log("menu called")

    }



    // stopwatch

const timer = document.querySelector('#usagetime');

let time = 0,
  interval;

function showTime() {
  time += 1;
  timer.innerHTML = toHHMMSS(time);
}

function start() {
  interval = setInterval(showTime, 1000);
}

function pause() {
  if (interval) {
    clearInterval(interval);
    interval = null;
  } else {
    interval = setInterval(showTime, 1000);
  }
}

function toHHMMSS(time) {
  let hours = Math.floor(time / 3600);
  let minutes = Math.floor((time - hours * 3600) / 60);
  let seconds = time - hours * 3600 - minutes * 60;

  hours = `${hours}`.padStart(2, '0');
  minutes = `${minutes}`.padStart(2, '0');
  seconds = `${seconds}`.padStart(2, '0');

  return hours + ':' + minutes + ':' + seconds;
}

function hello()
{
  console.log("test")
}



    // store wallet input value -----------------------

function getWalletValue() {
  var walletField = document.getElementById('walletinput').value;
  userId = walletField;

// store wallet key locally

chrome.storage.local.set({key: userId}, function() {
  console.log('Wallet address is set to ' + userId);
});

    // toast notification
  var x = document.getElementById("snackbar");
  x.className = "show";
  setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
  
  
}

var saveButton = document.getElementById('saveButton');
saveButton.addEventListener('click', getWalletValue, false); 